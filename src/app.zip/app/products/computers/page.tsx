// napage https://open-vsx.org/extension/PulkitGangwar/nextjs-snippets

export default function ComputersPage() {
    return (
        <div>Computers</div>
    );
}