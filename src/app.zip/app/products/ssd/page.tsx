export default function SSDPage() {
    return (
        <div>SSD </div>
    );
}