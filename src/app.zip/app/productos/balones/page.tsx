export default function BalonesPage() {
    return(
        <div>
            <h1>balones</h1>
        </div>
    );

}
