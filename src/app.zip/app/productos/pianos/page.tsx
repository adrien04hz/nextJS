export default function PianosPage() {

    return(
        <div>
            <h1>Pianos</h1>
        </div>
    );

}
