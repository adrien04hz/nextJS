export default function CajasPage() {

    return(
        <div>
            <h1>Cajas</h1>
        </div>
    );

}
